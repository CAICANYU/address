//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    address:'中山',
    selectIndex:0,//默认显示热门企业
    label:[
      {
        name:'爪企兽',
        pic:'/image/n1.png',
        id:0,
      },{
        name:'美食',
        pic:'/image/n2.png',
        id:1,
      },{
        name:'便利商超',
        pic:'/image/n3.png',
        id:2,
      },{
        name:'旅游',
        pic:'/image/n4.png',
        id:3,
      },{
        name:'闪送',
        pic:'/image/n5.png',
        id:4,
      },{
        name:'全球购',
        pic:'/image/n6.png',
        id:5,
      },{
        name:'酒店',
        pic:'/image/n7.png',
        id:6,
      },{
        name:'在线教育',
        pic:'/image/n8.png',
        id:7,
      },{
        name:'水果生鲜',
        pic:'/image/n9.png',
        id:8,
      },{
        name:'电影',
        pic:'/image/n10.png',
        id:9,
      }
    ],
    hotCompany:[
      {
        pic:'/image/hot.jpg',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.34
      },{
        pic:'/image/p1.png',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.34
      },{
        pic:'/image/p2.png',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.34
      },{
        pic:'/image/p3.png',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.34
      },
    ],
    informationList:[
      {
        id:0,
        title:'2018年仅剩一个月！一拨新规上线，将这样影响你的钱袋子→',
        stick:1,
        source:'央视财经',
        rv:7531,
        pic:'/image/hot.jpg',
      },{
        id:1,
        title:'举世闻名的巴拿马运河到底什么样？',
        stick:0,
        source:'央视财经',
        rv:2525,
        pic:'/image/hot.jpg',
      },{
        id:2,
        title:'习主席首次到访的这个国家有多酷，一图带你了解！',
        stick:0,
        source:'央视财经',
        rv:6535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },
    ]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  label:function(){
    wx.navigateToMiniProgram({
      appId: 'wxef96d47dcd8ee824',//注意：需在app.json中配置
      path: 'page/index/index?id=123',//路径
      extraData: {
        foo: 'bar'//携带数据
      },
      envVersion: 'develop',//trial 体验版  develop开发版  release正式版
      success(res) {
        // 打开成功
      },
      fail(res){
        //打卡失败
      }
    })
    // wx.navigateTo({
    //   url:'/pages/company/company'
    // })
  },
  labelTap:function(e){
    var _this = this;
    if(_this.data.selectIndex!=e.currentTarget.dataset.id){
      _this.setData({
        selectIndex:e.currentTarget.dataset.id
      })
    } 
  },
  /**
   * 滑动切换触发函数
   */
  bindChange: function (e) {
    var _this = this;
    _this.setData({
      selectIndex:e.detail.current
    })
  },
  hotCompanyMore:function(){
    wx.switchTab({
      url:'/pages/company/company'
    })
  },
  hotInformationMore:function(){
    wx.switchTab({
      url:'/pages/information/information'
    })
  },
  companyDetail:function(e){
    wx.navigateTo({
      url:'/pages/companyDetail/companyDetail'
    })
  },
  informationDetail:function(e){
    wx.navigateTo({
      url:'/pages/informationDetail/informationDetail'
    })
  },
  onShow:function(){
    var _this = this;
    if(app.globalData.address){
      _this.setData({
        address:app.globalData.address
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  scanCode:function(){
    // 只允许从相机扫码
    wx.scanCode({
      onlyFromCamera: false,
      success: (res) => {
        console.log(res);
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})
