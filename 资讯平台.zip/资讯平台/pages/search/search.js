var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tabId:0,
    tabId2:0,
    hotCompany:[
      {
        pic:'/image/hot.jpg',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.34
      },{
        pic:'/image/p1.png',
        title:'共享充电宝有限公司',
        label:[
          {
            name:'共享',
            color:'red'
          },{
            name:'移动',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:1.64
      },{
        pic:'/image/p2.png',
        title:'解忧杂货铺',
        label:[
          {
            name:'解忧',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:2.11
      },{
        pic:'/image/p3.png',
        title:'中国信通有限公司',
        label:[
          {
            name:'互联网',
            color:'red'
          },{
            name:'科技',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:2.43
      },{
        pic:'/image/p3.png',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:2.73
      },{
        pic:'/image/p3.png',
        title:'喜东东便利超市',
        label:[
          {
            name:'超市',
            color:'red'
          },{
            name:'便利店',
            color:'#3e67d9'
          },
        ],
        city:'中山',
        town:'石岐区',
        distance:3.03
      },
    ],
    showhotCompany:null,
    informationList:[
      {
        id:0,
        title:'2018年仅剩一个月！一拨新规上线，将这样影响你的钱袋子→',
        stick:1,
        source:'央视财经',
        rv:7531,
        pic:'/image/hot.jpg',
      },{
        id:1,
        title:'举世闻名的巴拿马运河到底什么样？',
        stick:0,
        source:'央视财经',
        rv:2525,
        pic:'/image/hot.jpg',
      },{
        id:2,
        title:'习主席首次到访的这个国家有多酷，一图带你了解！',
        stick:0,
        source:'央视财经',
        rv:6535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _this = this;
    _this.setData({
      showhotCompany:_this.data.hotCompany
    })
  },
  back:function(){
    wx.navigateBack({
      delta:1
    })
  },
  /**
   * companyDetail
   */
  companyDetail: function () {
    wx.navigateTo({
      url:'/pages/companyDetail/companyDetail'
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  tabSort: function (e) {
    var _this = this;
    _this.setData({
      tabId:e.currentTarget.dataset.id
    })
  },

  tabSort2: function (e) {
    var _this = this;
    _this.setData({
      tabId2:e.currentTarget.dataset.id
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this;
    if(app.globalData.address){
      _this.setData({
        address:app.globalData.address
      })
    }
  },

  /**
   * 搜索
   */
  searchBtn:function(e){
    var _this = this;
    var newListData = [];
    newListData = _this.data.hotCompany.filter((item) => {
      return item.title.indexOf(e.detail.value)>=0||item.city.indexOf(e.detail.value)>=0||item.town.indexOf(e.detail.value)>=0||item.label[0].name.indexOf(e.detail.value)>=0||item.label[1].name.indexOf(e.detail.value)>=0
    }); 
    _this.setData({
      showhotCompany:newListData
    })
  }, 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var　_this = this;
    wx.showLoading({title:'加载中'});
    var newarr = {
      pic:'/image/hot.jpg',
      title:'喜东东便利超市',
      label:[
        {
          name:'超市',
          color:'red'
        },{
          name:'便利店',
          color:'#3e67d9'
        },
      ],
      city:'中山',
      town:'石岐区',
      distance:2.34
    }
    setTimeout(function(){
      _this.setData({
        hotCompany:_this.data.hotCompany.concat(newarr),
        showhotCompany:_this.data.showhotCompany.concat(newarr),
      })
      wx.hideLoading();
    },1000)
      
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})