var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    informationList:[
      {
        id:0,
        title:'2018年仅剩一个月！一拨新规上线，将这样影响你的钱袋子→',
        stick:1,
        source:'央视财经',
        rv:7531,
        pic:'/image/hot.jpg',
      },{
        id:1,
        title:'举世闻名的巴拿马运河到底什么样？',
        stick:0,
        source:'央视财经',
        rv:2525,
        pic:'/image/hot.jpg',
      },{
        id:2,
        title:'习主席首次到访的这个国家有多酷，一图带你了解！',
        stick:0,
        source:'央视财经',
        rv:6535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * informationDetail--资讯详情
   */
  informationDetail: function () {
    wx.navigateTo({
      url:'/pages/informationDetail/informationDetail'
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this;
    if(app.globalData.address){
      _this.setData({
        address:app.globalData.address
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})