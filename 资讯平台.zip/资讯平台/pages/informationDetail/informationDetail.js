var app = getApp();
var wxParse = require('/../../wxParse/wxParse.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    bindfocus:0,
    focus:false,
    reply:0,//判断是回复还是，发表评论，0是回复，1是发表评论
    article:{
      title:'住在2400米的雪山上能吃到什么？',//文章标题
      follow:[
        {
          id:1,
          pic:'/image/p3.png',
          name:'共享充电宝公司',
          time:'2018-11-20 10:25'
        },
        {
          id:2,
          pic:'/image/p3.png',
          name:'共享充电宝公司2',
          time:'2018-11-20 10:25'
        }
      ],
      author:'阑珊',
      sign:['生活娱乐','电影','旅游出行','美食'],
      detail:'<div style="font-size:31rpx;color:#000;letter-spacing:4rpx;margin-bottom:20rpx;">推开欲知山居的木门，迎面就是一个用柴木堆起的照壁，让阿布一下子就想到一句话，欲知山中事，须问打柴人。听主理人说，这也是“开门见</div><br /><div><img src="/image/banner.jpg" alt="" border="0" /><br /></div><div><div><div style="font-size:31rpx;color:#000;letter-spacing:4rpx;margin-bottom:20rpx;margin-top:20rpx;">主理人在院子里栽培了不同品种的多肉，四季常青；叫不出名字的花卉，在冬日里也绽放得很好，是属于这一方天地的得天独厚。</div></div><div><br /></div><div><div style="font-size:31rpx;color:#000;letter-spacing:4rpx;margin-bottom:20rpx;">民宿内大量使用了原木材料，搭配纯白主色，不少人喜欢把它定义为北欧风格，阿布却觉得，融入了不少纳西元素的它要更热烈一些。</div></div></div><div><img src="/image/companyBanner.png" alt="" border="0" /><br /></div><div><br /></div><div><div><div style="font-size:31rpx;color:#000;letter-spacing:4rpx;margin-bottom:20rpx;">来自北欧设计师品牌的家具，丹麦的洗漱品牌，国内高端酒店同款的床品，天然乳胶的床垫与枕头……欲知山居可以打破很多人对于民宿的偏见：</div></div><div><br /></div><div><div style="font-size:31rpx;color:#000;letter-spacing:4rpx;margin-bottom:20rpx;">这里不止是贩卖故事与情怀的一个躯壳，也把五星级酒店的居住标准原封不动的复刻进来。</div></div></div>',
    },
    rate:[
      {
        avatarUrl:'/image/p1.png',
        nickName:'西门吹雪',
        points:12,
        content:'好故事是可以下酒，可民宿毕竟不是酒吧，品质和服务才应该是首位的。',
        rateTime:'1小时前',
        reply:3,
        replyDetail:[
          {
            replyName:'张飞',
            replyContent:'你是何人',
          },
          {
            replyName:'关羽',
            replyContent:'小老弟，我是你二哥啊',
          },
          {
            replyName:'张飞',
            replyContent:'原来是二哥，失礼了，请受小弟一拜。',
          },
        ]
      }
    ]
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _this = this;
    wx.getUserInfo({
        success: function(res) {
          _this.setData({
            userInfo:res.userInfo,
          })
        }
    })
    var article = this.data.article.detail;
    wxParse.wxParse('articleWx', 'html', article, this,5);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onGotUserInfo: function (e) {
    var _this = this;
    if(e.detail.errMsg=='getUserInfo:ok'){
      wx.getUserInfo({
          success: function(res) {
            _this.setData({
              userInfo:res.userInfo,
            })
          }
      })
    }
  },
  
  toservice:function(){
    wx.navigateTo({
      url:'/pages/service/service'
    })
  },
  
  /**
   * rateMore更多评价
   */
  rateMore: function () {
    var _this = this;
    wx.showLoading();
    var newArr = {
      avatarUrl:'/image/p2.png',
      nickName:'乔峰',
      points:123,
      content:'大家好，我是乔峰，',
      rateTime:'1周前',
      reply:13,
      replyDetail:[
        {
          replyName:'段誉',
          replyContent:'大哥好',
        },
        {
          replyName:'虚竹',
          replyContent:'...',
        },
        {
          replyName:'阿紫',
          replyContent:'来了老弟',
        },
      ]
    };
    _this.data.rate = _this.data.rate.concat(newArr);
    _this.setData({
      rate:_this.data.rate
    })
    wx.hideLoading();
  },

  /**
   * 输入框聚合焦点时
   */
  bindfocus: function () {
    var _this = this;
    _this.setData({
      bindfocus:1,
    })
    console.log('点击输入')
  },

  /**
   * 输入框失去焦点时
   */
  bindblur: function () {
    var _this = this;
    _this.setData({
      bindfocus:0,
      focus:false,
    })
    console.log('离开输入')
  },

  /**
   * resRate回复评论
   */
  resRate: function (e) {
    var _this = this;
    console.log(e)
    _this.setData({
      bindfocus:1,
      focus:true,
      reply:e.currentTarget.dataset.reply,
      replyIndex:e.currentTarget.dataset.index,
    })
  },
  
  /**
   * sentRate:评论点击发送
   */
  sentRate: function () {
    var _this = this;
    if(_this.data.reply==1){
      var newArr = {
        replyName:_this.data.userInfo.nickName,
        replyContent:_this.data.input,
      }
      _this.data.rate[_this.data.replyIndex].reply = _this.data.rate[_this.data.replyIndex].reply + 1;
      if(_this.data.rate[_this.data.replyIndex].replyDetail){
        _this.data.rate[_this.data.replyIndex].replyDetail = _this.data.rate[_this.data.replyIndex].replyDetail.concat(newArr);
      }else{
        var arr = [];
        arr.push(newArr);
        _this.data.rate[_this.data.replyIndex].replyDetail= arr;
      } 
      _this.setData({
        rate:_this.data.rate
      })
    }else{
      var newArr = {
        avatarUrl:_this.data.userInfo.avatarUrl,
        nickName:_this.data.userInfo.nickName,
        points:0,
        content:_this.data.input,
        rateTime:'刚刚',
        reply:0,
        replyDetail:null
      };
       var a = _this.data.rate.slice(0);
       a.unshift(newArr);
      _this.data.rate = a;
      _this.setData({
        rate:_this.data.rate
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onInput: function (e) {
    this.setData({
      input:e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})