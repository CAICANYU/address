var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    selectIndex:0,//分类选择项
    labelSelect:false,//分类列表
    labelList:[
      {
        title:'关注',
      },{
        title:'本地',
      },{
        title:'收藏',
      },{
        title:'优惠',
      },{
        title:'福利',
      }
    ],
    labelItem:[
      {
        name:'全部',
        pic:'/image/z1.png',
        color:'#3e67d9'
      },
      {
        name:'今日看点',
        pic:'/image/z2.png',
        color:'#6082dc'
      },
      {
        name:'头条新闻',
        pic:'/image/z3.png',
        color:'#a2ccfc'
      },
      {
        name:'科技频道',
        pic:'/image/z4.png',
        color:'#6082dc'
      },
      {
        name:'娱乐新闻',
        pic:'/image/z5.png',
        color:'#a2ccfc'
      },
      {
        name:'体育频道',
        pic:'/image/z6.png',
        color:'#6082dc'
      },
      {
        name:'汽车频道',
        pic:'/image/z7.png',
        color:'#a2ccfc'
      },
      {
        name:'美食天下',
        pic:'/image/z8.png',
        color:'#6082dc'
      },
      {
        name:'添加',
        pic:'/image/z9.png',
        color:'#ffc526'
      }
    ],
    labelItemShow:null,
    informationList:[
      {
        id:0,
        title:'2018年仅剩一个月！一拨新规上线，将这样影响你的钱袋子→',
        stick:1,
        source:'央视财经',
        rv:7531,
        pic:'/image/hot.jpg',
      },{
        id:1,
        title:'举世闻名的巴拿马运河到底什么样？',
        stick:0,
        source:'央视财经',
        rv:2525,
        pic:'/image/hot.jpg',
      },{
        id:2,
        title:'习主席首次到访的这个国家有多酷，一图带你了解！',
        stick:0,
        source:'央视财经',
        rv:6535,
        pic:'/image/hot.jpg',
      },{
        id:3,
        title:'重磅！广东市县机构改革进入全面实施阶段，一图读懂',
        stick:0,
        source:'央视财经',
        rv:535,
        pic:'/image/hot.jpg',
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    
  },

  /**
   * informationDetail--资讯详情
   */
  informationDetail: function () {
    wx.navigateTo({
      url:'/pages/informationDetail/informationDetail'
    })
  },
  labelTap:function(e){
    var _this = this;
    if(_this.data.selectIndex!=e.currentTarget.dataset.id){
      _this.setData({
        selectIndex:e.currentTarget.dataset.id
      })
    } 
    if(e.currentTarget.dataset.id==0){
      _this.setData({
        labelSelect:false
      })
    } 
  },
  /**
   * 滑动切换触发函数
   */
  bindChange: function (e) {
    var _this = this;
    _this.setData({
      selectIndex:e.detail.current
    })
    if(e.detail.current==0){
      _this.setData({
        labelSelect:false
      })
    }
  },

  /**
   * labelItem
   */
  labelItem: function (e) {
    var _this = this;
    if(e.currentTarget.dataset.name=='添加'){
      wx.navigateTo({
        url:'/pages/myConcern/myConcern'
      })
    }else{

      _this.setData({
        labelSelect:true,
      })

      // wx.navigateTo({
      //   url:'/pages/informationList/informationList'
      // })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this;
    if(app.globalData.address){
      _this.setData({
        address:app.globalData.address
      })
    }
    _this.data.labelItemShow = _this.data.labelItem;
    if(wx.getStorageSync('myConcern')){
      var list = [];
      var newArr = wx.getStorageSync('myConcern');
      for(var i=0;i<newArr.length;i++){
        if(newArr[i].active==1){
          var a = {
            name:newArr[i].name,
            pic:'/image/z8.png',
            color:'#a2ccfc',
          }
          list.push(a);
        }
      }
      var lastArr = _this.data.labelItem.pop();
      console.log(lastArr,'lastArr')
      _this.data.labelItemShow = _this.data.labelItemShow.concat(list);
      _this.data.labelItemShow = _this.data.labelItemShow.concat(lastArr);
       _this.data.labelItem = _this.data.labelItem.concat(lastArr);
    }
    _this.setData({
      labelItemShow:_this.data.labelItemShow,
      labelItem:_this.data.labelItem,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})