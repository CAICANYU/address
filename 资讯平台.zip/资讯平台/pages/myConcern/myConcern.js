var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    myConcern:[
      {'name':'新闻','id':1,'active':0},
      {'name':'知识','id':2,'active':0},
      {'name':'经验','id':3,'active':0},
      {'name':'搞笑','id':4,'active':0},
      {'name':'行业','id':5,'active':0},
      {'name':'情感','id':6,'active':0},
      {'name':'鸡汤','id':7,'active':0},
      {'name':'爆料','id':8,'active':0},
      {'name':'故事','id':9,'active':0},
      {'name':'励志','id':10,'active':0},
      {'name':'八卦','id':11,'active':0},
      {'name':'观点','id':12,'active':0},
      {'name':'排行','id':13,'active':0},
      {'name':'案例','id':14,'active':0},
      {'name':'研究','id':15,'active':0},
      {'name':'旅游','id':16,'active':0},
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    
  },
  /**
   * active
   */
  active: function (e) {
    var _this = this;
    _this.data.myConcern[e.currentTarget.dataset.index].active = _this.data.myConcern[e.currentTarget.dataset.index].active==0?1:0;
    _this.setData({
      myConcern:_this.data.myConcern
    })
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this;
    if(wx.getStorageSync('myConcern')){
      this.setData({
        myConcern:wx.getStorageSync('myConcern')
      })
    } 
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  btn: function () {
    var _this = this;
    wx.setStorageSync('myConcern',_this.data.myConcern);
    wx.navigateBack({
        delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})