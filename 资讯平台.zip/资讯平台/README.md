# 资讯平台小程序

# 声明
"pages/index/index",//首页
"pages/information/information",//资讯-分类
"pages/informationList/informationList",//资讯-列表
"pages/informationDetail/informationDetail",//资讯-新闻内容
"pages/company/company",//企业列表
"pages/companyLabel/companyLabel",//企业分类
"pages/companyDetail/companyDetail",//企业详情
"pages/companyCode/companyCode",//企业二维码
"pages/user/user",//个人信息中心
"pages/apply/apply",//申请
"pages/service/service",//客服
"pages/myConcern/myConcern",//我的关注
"pages/about/about",//关于我们